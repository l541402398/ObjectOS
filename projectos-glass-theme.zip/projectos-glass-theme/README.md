# ProjectOS V1.6 玻璃拟态主题示例

此仓库是可运行的 **独立样式演示壳**，不是替换现有 ProjectOS 的业务代码。

## 运行
```bash
pnpm install
pnpm dev
```

## 集成到既有 Monorepo
1. 将 `src/styles/glass.css` 放到 `apps/desktop/src/renderer/styles/glass.css`。
2. 将 `src/ui/GlassShell.tsx` 的布局与玻璃类名合并到现有 layouts；保留已有路由与权限逻辑。
3. 在现有 `packages/design-tokens`、`packages/themes` 中登记 CSS token，复用 Ant Design ConfigProvider。
4. `public/wallpaper.jpg` 是壁纸占位文件名；替换成授权的独立原图。
5. 不直接在渲染进程访问 Node API；由 Electron preload 暴露白名单 IPC 方法。
6. 把示例 window.projectOS.getOverview / navigate / search 适配为既有 IPC 方法；实际项目中优先直接挂载既有 route outlet。
7. 保留现有 Agent Runtime/Harness、Skills、Tools/MCP、外部 Agent 的业务边界和真实连接状态。

## 说明
缺失 IPC 时数字显示 `—`，不会伪造运行数据。
本包不包含虚构的业务接口，也不包含从 UI 设计图裁出的“壁纸”。
