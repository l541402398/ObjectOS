import React from 'react';
import {createRoot} from 'react-dom/client';
import {ConfigProvider, theme} from 'antd';
import {GlassShell} from './ui/GlassShell';
import './styles/glass.css';
createRoot(document.getElementById('root')!).render(<React.StrictMode><ConfigProvider theme={{algorithm:theme.darkAlgorithm,token:{colorPrimary:'#b4caff',borderRadius:16,fontFamily:'Inter, "Microsoft YaHei", sans-serif'}}}><GlassShell /></ConfigProvider></React.StrictMode>);
