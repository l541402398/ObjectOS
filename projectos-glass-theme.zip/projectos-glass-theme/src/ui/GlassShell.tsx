import React, {useState} from 'react';
import {Button, Input, Typography, Empty, Switch} from 'antd';
import {AppstoreOutlined, FolderOpenOutlined, RobotOutlined, ToolOutlined, ApiOutlined, BookOutlined, SettingOutlined, SearchOutlined, MenuFoldOutlined} from '@ant-design/icons';
const navigation=[
{key:'overview',label:'工作台',icon:<AppstoreOutlined/>},
{key:'projects',label:'项目管理',icon:<FolderOpenOutlined/>},
{key:'agents',label:'Agent 管理',icon:<RobotOutlined/>},
{key:'tools',label:'工具与插件',icon:<ToolOutlined/>},
{key:'external',label:'外部 Agent',icon:<ApiOutlined/>},
{key:'knowledge',label:'知识库',icon:<BookOutlined/>},
{key:'settings',label:'设置',icon:<SettingOutlined/>}
];
export type ProjectOSBridge={navigate?:(key:string)=>void;search?:(query:string)=>void;getOverview?:()=>Promise<{projects:number;agents:number;tools:number}>};
declare global {interface Window {projectOS?:ProjectOSBridge}}
export function GlassShell(){
const [active,setActive]=useState('overview');
const [query,setQuery]=useState('');
const [reduceGlass,setReduceGlass]=useState(false);
const [collapsed,setCollapsed]=useState(false);
const [overview,setOverview]=useState<{projects:number;agents:number;tools:number}|null>(null);
React.useEffect(()=>{let mounted=true;window.projectOS?.getOverview?.().then(data=>{if(mounted)setOverview(data)}).catch(()=>{});return()=>{mounted=false}},[]);
function navigate(key:string){setActive(key);window.projectOS?.navigate?.(key)}
return <div className={'os-root '+(reduceGlass?'reduce-glass':'')}>
<div className="wallpaper" aria-hidden="true"/><div className="ambient" aria-hidden="true"/>
<div className={'desktop '+(collapsed?'collapsed':'')}>
<aside className="glass sidebar"><div className="brand"><span className="brand-icon">✦</span>{!collapsed&&<strong>ProjectOS <small>V1.6</small></strong>}<Button type="text" icon={<MenuFoldOutlined/>} onClick={()=>setCollapsed(v=>!v)} aria-label="切换侧栏"/></div>
<nav>{navigation.map(n=><button key={n.key} className={'nav-item '+(active===n.key?'selected':'')} onClick={()=>navigate(n.key)}>{n.icon}{!collapsed&&<span>{n.label}</span>}</button>)}</nav>
<div className="sidebar-bottom">{!collapsed&&<span>玻璃透明度降低</span>}<Switch size="small" checked={reduceGlass} onChange={setReduceGlass}/></div></aside>
<div className="workspace"><header className="glass topbar"><div className="window-dots"><i/><i/><i/></div><Input prefix={<SearchOutlined/>} value={query} onChange={e=>setQuery(e.target.value)} onPressEnter={()=>window.projectOS?.search?.(query)} placeholder="搜索项目、Agent、工具..." allowClear/><span className="topbar-label">ProjectOS 工作空间</span></header>
<main className="main"><div className="heading"><div><Typography.Title level={2}>{navigation.find(n=>n.key===active)?.label}</Typography.Title><p>统一管理项目生命周期、Agent 与工具能力</p></div><span className="eyebrow">DESKTOP WORKSPACE</span></div>
{active==='overview'?<><section className="stats"><article className="glass metric"><span>项目总数</span><strong>{overview?.projects ?? '—'}</strong><small>来自项目服务</small></article><article className="glass metric"><span>Agent 总数</span><strong>{overview?.agents ?? '—'}</strong><small>来自 Agent 服务</small></article><article className="glass metric"><span>已接入工具</span><strong>{overview?.tools ?? '—'}</strong><small>来自工具注册表</small></article></section><section className="glass content"><div className="section-head"><h3>工作空间</h3><span>实际数据通过 IPC 加载</span></div><Empty description="连接现有 ProjectOS 数据服务后展示项目、任务与 Agent 状态"/></section></>:<section className="glass content"><div className="section-head"><h3>{navigation.find(n=>n.key===active)?.label}</h3></div><Empty description="在此挂载现有业务路由组件；不要复制或重建业务功能"/></section>}
</main></div></div></div>
}
